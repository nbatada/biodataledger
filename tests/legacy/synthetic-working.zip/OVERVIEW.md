# Synthetic Project Bundle Trial

Generated overview; authoritative state: .nb_project_bundle/project.json
State revision: 3
Purpose: Find retained QC figures and their declared sources
Next task: Inspect FIG-001@1 and report its known sources and unknown execution evidence.

Records are declared unless a specific check is recorded. Import does not execute code.
Scientific acceptance and reproduction are not established by this bundle.

## Current inputs
- qc: DATA-001@1

## Figures
- FIG-001@1: library (qc); analysis ANA-001@1
- FIG-002@1: genes (qc); analysis ANA-001@1
- FIG-003@1: Legacy T-cell clonality (synthetic) (legacy); analysis unknown

Inspect DEPENDENCIES.json for omitted/missing files. Record inspection is not proof of resumability.
