library(BioDataLedger)
main <- function() {
 root<-tempfile('figure-sources-');dir.create(root);on.exit(unlink(root,recursive=TRUE),add=TRUE)
 writeLines('analytical',file.path(root,'analysis.csv'));writeLines('rendering',file.path(root,'render.csv'))
 writeLines('# synthetic source',file.path(root,'plot.R'));writeLines('# helper',file.path(root,'helper.R'));writeLines('<svg/>',file.path(root,'figure.svg'))
 p<-ProjectBundle$create('synthetic figure sources',root)
 for(i in seq_len(49)) data<-p$register_data('analysis.csv','input')
 for(i in seq_len(8)) render<-p$register_data('render.csv','result',hash=TRUE)
 support<-p$register_data('helper.R','support',hash=TRUE)
 for(i in seq_len(14)) analysis<-p$register_analysis('synthetic comparison',list(data),code='plot.R',method='fixture',params=list(threshold=0.25))
 for(i in seq_len(75)) figure<-p$register_figure('figure.svg','synthetic',analysis=analysis)
 original<-readBin(file.path(root,'plot.R'),'raw',1000)
 stopifnot(identical(p$read_figure_source(figure)$content,original))
 p$save()
 stopifnot(data$id=='DATA-049',render$id=='DATA-057',analysis$id=='ANA-014',figure$id=='FIG-075')
 original<-readBin(file.path(root,'plot.R'),'raw',1000)
 stopifnot(identical(p$read_figure_source(figure)$content,original))
 declarations<-list(rendering_inputs=list(render),relationship='unknown',generating_code=list(record=analysis,index=0L),dependencies=list(list(path='helpers/helper.R',ref=support)),asset_id='study:panel-A')
 f<-p$update_record(figure,list(figure_sources=declarations),'explicit rendering context')
 v<-p$get_figure(f)
 stopifnot(identical(v$inputs,list(data)),identical(v$rendering_inputs,list(render)),v$evidence$execution=='unknown',v$rendering_relationship=='unknown',v$generating_code$integrity=='not_checked')
 stopifnot(identical(p$get_figure(asset_id='study:panel-A')$ref,f),identical(p$get_figure('FIG-075',revision=2L)$ref,f))
 fail<-function(expr) stopifnot(inherits(try(force(expr),silent=TRUE),'try-error'))
 stopifnot(length(p$find_figures('study:panel-A'))==1L,length(p$find_figures('figure.svg'))==75L,
           p$get_figure(f,compact=TRUE)$asset_id=='study:panel-A')
 details<-p$get_figure(f)$details;details$entry_point<-'draw_umap_by_library'
 named<-p$update_record(f,list(details=details),'record function declaration')
 stopifnot(p$get_figure(named,compact=TRUE)$entry_point=='draw_umap_by_library',
           is.null(p$get_figure(figure,compact=TRUE)$entry_point),
           p$get_figure(named,compact=TRUE)$execution=='unknown')
 fail(p$get_figure('FIG-075'));fail(p$get_figure(path='figure.svg'))
 writeLines('# changed original',file.path(root,'plot.R'))
 stopifnot(identical(p$read_figure_source(f)$content,original))
 p$save();path<-file.path(root,'.nb_project_bundle','project.json');before<-readBin(path,'raw',file.info(path)$size)
 unlink(file.path(root,'render.csv'));unlink(file.path(root,'helper.R'))
 report<-p$get_figure(f,compact=TRUE,check_files=TRUE)
 stopifnot(nchar(jsonlite::toJSON(report,auto_unbox=TRUE,null='null'),type='bytes')<=4096L,
           'rendering_relationship' %in% unlist(report$missing),'rendering_file' %in% unlist(report$missing),identical(report$rendering_details[[1]]$available,FALSE),
           identical(p$get_figure(f)$figure_sources$dependency_completeness,'unknown'),
           identical(before,readBin(path,'raw',file.info(path)$size)),!p$status()$unsaved)
 bad<-declarations;bad$dependencies<-list(list(path='../escape.R',ref=support))
 fail(p$update_record(f,list(figure_sources=bad),'invalid dependency'))
 bad<-declarations;bad$generating_code$sha256<-paste(rep('0',64),collapse='')
 fail(p$update_record(f,list(figure_sources=bad),'invalid digest'))
 snapshot<-file.path(root,p$get_figure(f)$generating_code$snapshot);unlink(snapshot)
 fail(p$read_figure_source(f));stopifnot(file.exists(file.path(root,'plot.R')))
}
main()
